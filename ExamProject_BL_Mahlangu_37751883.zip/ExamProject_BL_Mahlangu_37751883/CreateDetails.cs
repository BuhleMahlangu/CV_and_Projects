﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ExamProject_BL_Mahlangu_37751883
{
    public partial class CreateDetails : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataAdapter adapt;
        DataSet ds;
        public const string connstr = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=Users;Integrated Security=True";

        public CreateDetails()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                using (conn = new SqlConnection(connstr))
                {
                    int usersID = int.Parse(txtUsersID.Text);
                    string username = txtUsername.Text;
                    string password = txtPassword.Text;
                    string email = txtEmail.Text;
                    string name = txtName.Text;
                    string surname = txtSurname.Text;
                    string membershipLevel = txtMembership.Text;

                    conn.Open();
                    string insertquery = "INSERT INTO UsersTable (usersID, username, password, email, name, surname, membershipLevel) VALUES (@UsersID, @Username, @Password, @Email, @Name, @Surname, @MembershipLevel)";

                    cmd = new SqlCommand(insertquery, conn);
                    cmd.Parameters.AddWithValue("@UsersID", usersID);
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Surname", surname);
                    cmd.Parameters.AddWithValue("@MembershipLevel", membershipLevel);
                    int rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            try
            {
                using (conn = new SqlConnection(connstr))
                {
                    conn.Open();
                    string select = "SELECT * FROM UsersTable";
                    cmd = new SqlCommand(select, conn);
                    adapt = new SqlDataAdapter(cmd);
                    DataTable table = new DataTable();
                    adapt.Fill(table);
                    dataGridShow.DataSource = table;

                    dataGridShow.Refresh();
                    dataGridShow.AutoGenerateColumns = true;
                    conn.Close();
                }
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            login.ShowDialog();
        }

        private void CreateDetails_Load(object sender, EventArgs e)
        {
            CreateDetails create = new CreateDetails();
            create.Focus();
        }
    }
}
