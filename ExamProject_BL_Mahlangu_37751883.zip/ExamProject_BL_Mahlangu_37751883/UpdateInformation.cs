﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ExamProject_BL_Mahlangu_37751883
{
    public partial class UpdateInformation : Form
    {
        SqlConnection conn;
        public const string connstr = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=Users;Integrated Security=True";
        SqlCommand cmd;
        SqlDataAdapter adapt;
        DataSet ds;

        public UpdateInformation()
        {
            InitializeComponent();
        }

        private void btnUpdateDetails_Click(object sender, EventArgs e)
        {
            try
            {
                string newEmail = txtNewEmail.Text;
                string newPassword = txtNewPassword.Text;
                string newMembershipLevel = txtNewMembershipLevel.Text;
                int userID = int.Parse(txtUserID.Text);
                        
                using (conn = new SqlConnection(connstr))
                {
                    string update = "UPDATE UsersTable SET Email = @NewEmail, Password = @NewPassword, MembershipLevel = @NewMembershipLevel WHERE UsersID = @UserID";
                    conn.Open();
                    cmd = new SqlCommand(update, conn);

                    cmd.Parameters.AddWithValue("@NewEmail", newEmail);
                    cmd.Parameters.AddWithValue("@NewPassword", newPassword);
                    cmd.Parameters.AddWithValue("@NewMembershipLevel", newMembershipLevel);
                    cmd.Parameters.AddWithValue("@UserID", userID);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Information updated successfully!");
                    conn.Close();
                }
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            ViewAndUpdateDetails view = new ViewAndUpdateDetails();
            view.ShowDialog();
        }
    }
}
