﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ExamProject_BL_Mahlangu_37751883
{
    public partial class ViewAndUpdateDetails : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        public const string connstr = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=Users;Integrated Security=True";
        SqlDataAdapter adapt;
        DataSet ds;

        public ViewAndUpdateDetails()
        {
            InitializeComponent();
        }

        private void ViewAndUpdateDetails_Load(object sender, EventArgs e)
        {
            try
            {
                using (conn = new SqlConnection(connstr))
                {
                    conn.Open();
                    string select = "SELECT * FROM UsersTable";
                    cmd = new SqlCommand(select, conn);
                    adapt = new SqlDataAdapter(cmd);
                    DataTable table = new DataTable();
                    adapt.Fill(table);
                    dataGridView1.DataSource = table;

                    dataGridView1.Refresh();
                    dataGridView1.AutoGenerateColumns = true;
                    conn.Close();
                }
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchQuery = txtSearch.Text;

            try
            {
                using (conn = new SqlConnection(connstr))
                {
                    string select = "SELECT UsersID, Username, Password, Email, Name, Surname, MembershipLevel FROM UsersTable WHERE Name LIKE @SearchQuery";
                    conn.Open();
                    cmd = new SqlCommand(select, conn);
                    cmd.Parameters.AddWithValue("@SearchQuery", "%" + searchQuery + "%");

                    adapt = new SqlDataAdapter(cmd);
                    DataTable table = new DataTable();
                    adapt.Fill(table);

                    dataGridView1.DataSource = table;
                    dataGridView1.Refresh();
                    conn.Close();
                }
                
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            UpcomingEvents events = new UpcomingEvents();
            events.ShowDialog();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateInformation update = new UpdateInformation();
            update.ShowDialog();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                using (conn = new SqlConnection(connstr))
                {
                    conn.Open();
                    string select = "SELECT * FROM UsersTable";
                    cmd = new SqlCommand(select, conn);
                    adapt = new SqlDataAdapter(cmd);
                    DataTable table = new DataTable();
                    adapt.Fill(table);
                    dataGridView1.DataSource = table;

                    dataGridView1.Refresh();
                    dataGridView1.AutoGenerateColumns = true;
                    conn.Close();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0 && e.ColumnIndex == dataGridView1.Columns["Delete"].Index)
            {
                int UsersIDtoDelete = (int)dataGridView1.Rows[e.RowIndex].Cells["UsersID"].Value;

                DeleteUsersDetail(UsersIDtoDelete);

                dataGridView1.Rows.RemoveAt(e.RowIndex);
            }
        }

        private void DeleteUsersDetail(int UsersID)
        {
            string delete = "DELETE FROM UsersTable WHERE UsersID = @UsersID";
            using (conn = new SqlConnection(connstr))
            {
                using (cmd = new SqlCommand(delete, conn))
                {
                    cmd.Parameters.AddWithValue("@UsersID", UsersID);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
