﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ExamProject_BL_Mahlangu_37751883
{
    public partial class Form1 : Form
    {
        SqlConnection conn;
        private const string connstr = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=Users;Integrated Security=True";
        SqlCommand cmd;
        SqlDataAdapter adapt;
        DataSet ds;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CreateDetails create = new CreateDetails();
            create.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (VerifyLogin(username, password))
            {
                // Successful login
                MessageBox.Show("Login successful!");
                DialogResult = DialogResult.OK;

                ViewAndUpdateDetails view = new ViewAndUpdateDetails();
                view.ShowDialog();
                Close();
            }
            else
            {
                // Invalid login
                MessageBox.Show("Invalid username or password. Please try again.");
            }
        }

        private bool VerifyLogin(string username, string password)
        {
            bool isValid = false;

            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();

                string query = "SELECT COUNT(*) FROM UsersTable WHERE Username LIKE @Username AND Password LIKE @Password";
                cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@Password", password);

                using (SqlDataReader read = cmd.ExecuteReader())
                {
                    if (read.Read())
                    {
                        int count = read.GetInt32(0);

                        if (count > 0)
                        {
                            isValid = true;
                        }
                    }
                }

                
            }

            return isValid;

        }

        private DataTable GetUpcomingEvents(string username)
        {
            DataTable eventsTable = new DataTable();

            using (conn = new SqlConnection(connstr))
            {
                string query = "SELECT EventName, EventDate, EventTime, Venue FROM Events WHERE username = @Username";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Username", username);

                conn.Open();
                adapt = new SqlDataAdapter(cmd);
                adapt.Fill(eventsTable);
            }

            return eventsTable;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
