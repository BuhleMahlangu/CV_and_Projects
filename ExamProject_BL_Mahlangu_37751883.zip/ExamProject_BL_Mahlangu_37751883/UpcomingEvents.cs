﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ExamProject_BL_Mahlangu_37751883
{
    public partial class UpcomingEvents : Form
    {
        SqlConnection conn;
        public const string connstr = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=Users;Integrated Security=True";
        SqlCommand cmd;
        DataSet ds;
        SqlDataAdapter adapt;

        public UpcomingEvents()
        {
            InitializeComponent();
        }

        private void UpcomingEvents_Load(object sender, EventArgs e)
        {
            try
            {
                using (conn = new SqlConnection(connstr))
                {
                    string select = "SELECT * FROM EventsTable";
                    conn.Open();
                    cmd = new SqlCommand(select, conn);
                    adapt = new SqlDataAdapter(cmd);
                    DataTable table = new DataTable();
                    adapt.Fill(table);
                    dataGridView1.DataSource = table;

                    dataGridView1.Refresh();
                    dataGridView1.AutoGenerateColumns = true;

                    conn.Close();
                }
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            int EventID = int.Parse(txtEventID.Text);
            string EventName = txtEventName.Text;
            string Description = txtDescription.Text;
            DateTime EventDate;
            if(DateTime.TryParse(txtEventDate.Text, out EventDate))
            {

            }

            string EventTime = txtEventTime.Text;
            TimeSpan timeSpan;
            if(TimeSpan.TryParse(EventTime, out timeSpan))
            {

            }

            string Venue = txtVenue.Text;
            int Capacity = int.Parse(txtCapacity.Text);
            int HostID = int.Parse(txtHostID.Text);

            using (conn = new SqlConnection(connstr))
            {
                string insert = "INSERT INTO EventsTable (EventID, EventName, Description, EventDate, EventTime, Venue, Capacity, HostID) VALUES (@EventID, @EventName, @Description, @EventDate, @EventTime, @Venue, @Capacity, @HostID)";
                conn.Open();
                cmd = new SqlCommand(insert, conn);

                cmd.Parameters.AddWithValue("@EventID", txtEventID.Text);
                cmd.Parameters.AddWithValue("@EventName", txtEventName.Text);
                cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                cmd.Parameters.AddWithValue("@EventDate", txtEventDate.Text);
                cmd.Parameters.AddWithValue("@EventTime", txtEventTime.Text);
                cmd.Parameters.AddWithValue("@Venue", txtVenue.Text);
                cmd.Parameters.AddWithValue("@Capacity", txtCapacity.Text);
                cmd.Parameters.AddWithValue("HostID", txtHostID.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("New event created successfully!");
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            using (conn = new SqlConnection(connstr))
            {
                string select = "SELECT * FROM EventsTable";
                conn.Open();
                cmd = new SqlCommand(select, conn);
                adapt = new SqlDataAdapter(cmd);
                DataTable table = new DataTable();
                adapt.Fill(table);
                dataGridView1.DataSource = table;

                dataGridView1.Refresh();
                dataGridView1.AutoGenerateColumns = true;
                conn.Close();
            }
        }

        private void btnSearchEvent_Click(object sender, EventArgs e)
        {
            string searchQuery = txtSearchEvent.Text;

            try
            {
                using (conn = new SqlConnection(connstr))
                {
                    string select = "SELECT EventID, EventName, Description, EventDate, EventTime, Venue, Capacity, HostID FROM EventsTable WHERE EventName LIKE @SearchQuery";
                    conn.Open();
                    cmd = new SqlCommand(select, conn);
                    cmd.Parameters.AddWithValue("@SearchQuery", "%" + searchQuery + "%");

                    adapt = new SqlDataAdapter(cmd);
                    DataTable table = new DataTable();
                    adapt.Fill(table);

                    dataGridView1.DataSource = table;
                    dataGridView1.Refresh();
                    conn.Close();
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {

            Register reg = new Register();
            reg.ShowDialog();
        }

        private void cbEvents_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
