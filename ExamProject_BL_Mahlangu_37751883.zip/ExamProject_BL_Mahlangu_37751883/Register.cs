﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ExamProject_BL_Mahlangu_37751883
{
    public partial class Register : Form
    {
        SqlConnection conn;
        public const string connstr = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=Users;Integrated Security=True";
        SqlCommand cmd;
        SqlDataAdapter adapt;
        DataSet ds;

        public Register()
        {
            InitializeComponent();
        }

        private void Register_Load(object sender, EventArgs e)
        {
            try
            {
                using (conn = new SqlConnection(connstr))
                {
                    string select = "SELECT * FROM EventRegistration";
                    conn.Open();
                    cmd = new SqlCommand(select, conn);
                    adapt = new SqlDataAdapter(cmd);
                    DataTable table = new DataTable();
                    adapt.Fill(table);
                    dataGridView1.DataSource = table;

                    dataGridView1.Refresh();
                    dataGridView1.AutoGenerateColumns = true;

                    List<string> eventNames = RetrieveEventNames();
                    cbEvents.DataSource = eventNames;

                    conn.Close();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private List<string> RetrieveEventNames()
        {
            List<string> eventNames = new List<string>();

            using (SqlConnection connection = new SqlConnection(connstr))
            {
                connection.Open();

                string query = "SELECT EventName FROM EventsTable";

                cmd = new SqlCommand(query, connection);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string eventName = reader.GetString(0);
                        eventNames.Add(eventName);
                    }
                }
            }

            return eventNames;
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                using (conn = new SqlConnection(connstr))
                {
                    string Name = txtName.Text;
                    int RegistrationID = int.Parse(txtRegistration.Text);
                    int Price = int.Parse(txtPrice.Text);
                    string Surname = txtSurname.Text;
                    string EventName = cbEvents.SelectedItem.ToString();

                    conn.Open();
                    string insertquery = "INSERT INTO EventRegistration (Name, Surname, RegistrationID, EventName, Price) VALUES (@Name, @Surname, @RegistrationID, @EventName, @Price)";

                    cmd = new SqlCommand(insertquery, conn);
                    cmd.Parameters.AddWithValue("@Name", Name);
                    cmd.Parameters.AddWithValue("@Surname", Surname);
                    cmd.Parameters.AddWithValue("@RegistrationID", RegistrationID);
                    cmd.Parameters.AddWithValue("@EventName", EventName);
                    cmd.Parameters.AddWithValue("@Price", Price);

                    int rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                using (conn = new SqlConnection(connstr))
                {
                    string select = "SELECT * FROM EventRegistration";
                    conn.Open();
                    cmd = new SqlCommand(select, conn);
                    adapt = new SqlDataAdapter(cmd);
                    DataTable table = new DataTable();
                    adapt.Fill(table);
                    dataGridView1.DataSource = table;

                    dataGridView1.Refresh();
                    dataGridView1.AutoGenerateColumns = true;

                    conn.Close();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
