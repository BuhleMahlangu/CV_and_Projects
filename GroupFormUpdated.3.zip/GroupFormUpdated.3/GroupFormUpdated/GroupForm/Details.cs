﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace grp3PROJECT
{
    public partial class Details : Form
    {
        public Details()
        {
            InitializeComponent();
        }

        SqlConnection conn;
        SqlCommand command;
        SqlDataAdapter adapter;
        SqlDataReader reader;
        DataSet ds;
        private void button2_Click(object sender, EventArgs e)
        {

            //Open the update form
            UpdateForm update = new UpdateForm();
            update.Show();
            this.Hide();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Order form
            Order newOrder = new Order();
            newOrder.Show();
            this.Hide();
        }

        private void btnDisplayOner_Click(object sender, EventArgs e)
        {

            //Displaying the Owners details
            string conStr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Desktop\GroupFormUpdated.2\GroupFormUpdated\GroupForm\Spaza_DB.mdf;Integrated Security=True";
            conn = new SqlConnection(conStr);

            try
            {
                conn.Open();
                // displaying the Order table on a data grid view
                string sql = @"SELECT * FROM [Owner]";
                command = new SqlCommand(sql, conn);
                adapter = new SqlDataAdapter();
                ds = new DataSet();

                adapter.SelectCommand = command;
                adapter.Fill(ds, "Owner");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Owner";
                conn.Close();

            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnDisplayCustomer_Click(object sender, EventArgs e)
        {
            string conStr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Desktop\GroupFormUpdated.2\GroupFormUpdated\GroupForm\Spaza_DB.mdf;Integrated Security=True";
            conn = new SqlConnection(conStr);

            try
            {
                conn.Open();
                // displaying the Order table on a data grid view
                string sql = @"SELECT * FROM [Customer]";
                command = new SqlCommand(sql, conn);
                adapter = new SqlDataAdapter();
                ds = new DataSet();

                adapter.SelectCommand = command;
                adapter.Fill(ds, "Customer");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Customer";
                conn.Close();

            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //close the Aplication
            Application.Exit();
        }
    }
}
