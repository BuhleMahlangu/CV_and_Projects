﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace grp3PROJECT
{
    public partial class Supplier : Form
    {
        //Declare and assign the field
        SqlConnection cnn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Desktop\GroupFormUpdated.2\GroupFormUpdated\GroupForm\Spaza_DB.mdf;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataSet data = new DataSet();
        public Supplier()
        {
            InitializeComponent();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            try
            {
                cnn.Open();

                cmd = new SqlCommand("SELECT * FROM product", cnn);

                adapter.SelectCommand = cmd;
                adapter.Fill(data, "Product");

                dgvProducts.DataSource = data;
                dgvProducts.DataMember = "Product";

                cnn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnMaintainSupplier_Click(object sender, EventArgs e)
        {
            MaintainSupplier maintainSupplier = new MaintainSupplier();
            maintainSupplier.Show();
            this.Hide();
        }
    }
}
