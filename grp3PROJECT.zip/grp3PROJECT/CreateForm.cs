﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace grp3PROJECT
{
    public partial class CreateForm : Form
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataAdapter adapt;
        DataSet ds;
        public const string connstr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Desktop\grp3PROJECT\Spaza_DB.mdf;Integrated Security=True";

        public CreateForm()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                using(conn = new SqlConnection(connstr))
                {
                    string ownerID = txtOwnerID.Text;
                    string contact = txtContactNum.Text;
                    string email = txtEmail.Text;

                    conn.Open();
                    string insertquery = "INSERT INTO Owner (ownerID, contact, email) VALUES (@ownerID, @contact, @email)";

                    cmd = new SqlCommand(insertquery, conn);
                    cmd.Parameters.AddWithValue("@ownerID", ownerID);
                    cmd.Parameters.AddWithValue("@contact", contact);
                    cmd.Parameters.AddWithValue("@email", email);

                    int rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CreateForm_Load(object sender, EventArgs e)
        {
            CreateForm create = new CreateForm();
            if (create.Visible == true)
            {
                loginForm log = new loginForm();
                log.Visible = false;
            }
        }
    }
}
